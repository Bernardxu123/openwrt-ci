#!/bin/sh
. /usr/share/openclash/log.sh
. /lib/functions.sh

# This script is called by /etc/init.d/openclash
# Add your custom firewall rules here, they will be added after the end of the OpenClash iptables rules

LOG_TIP "Start Add Custom Firewall Rules..."

# 2026-10-22: fail-closed IPv6 / fake-IP guard
if [ -x /usr/bin/openclash-v6-guard.sh ]; then
    /usr/bin/openclash-v6-guard.sh
fi

exit 0
